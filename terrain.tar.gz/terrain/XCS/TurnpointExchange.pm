package XCS::TurnpointExchange;

my $tx_base_url = "http://soaring.aerobatics.ws/TP";
for my $continent (qw(
